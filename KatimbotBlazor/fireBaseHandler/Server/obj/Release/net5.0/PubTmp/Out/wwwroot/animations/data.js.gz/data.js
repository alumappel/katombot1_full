(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F0CB7F").s().p("AgzA0IAAhnIBnAAIAABng");
	this.shape.setTransform(5.175,5.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,10.4,10.4), null);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC9CCB").s().p("AgvAwIAAhfIBfAAIAABfg");
	this.shape.setTransform(4.75,4.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(0,0,9.5,9.5), null);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC9CCB").s().p("Ag2A3IAAhtIBtAAIAABtg");
	this.shape.setTransform(5.5,5.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,11,11), null);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC9CCB").s().p("AgmAnIAAhNIBNAAIAABNg");
	this.shape.setTransform(3.875,3.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(0,0,7.8,7.8), null);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC9CCB").s().p("Ag3A4IAAhvIBvAAIAABvg");
	this.shape.setTransform(5.575,5.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,11.2,11.2), null);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AC9CCB").s().p("AhSBSIAAikICkAAIAACkg");
	this.shape.setTransform(8.25,8.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,16.5,16.5), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F0CB7F").s().p("AhaAAIBahaIBbBaIhbBag");
	this.shape.setTransform(9.075,9.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,18.2,18.1), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DEA27B").s().p("AA3CVQBhj5Acl7IgYO5IlPAGQCQhgBajrg");
	this.shape.setTransform(119.2,226.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8D4B1").s().p("AgjASQgCgGAjgRIAlgTQACAHgBADIgFAFIgdAOQgVALgOAJg");
	this.shape_1.setTransform(4.929,102.0301,1.348,1.348,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DEA27B").s().p("AgkAQQgCgFAkgSQAdgPAKgDQABAJgIAGQgHAFgVAKQgUALgOAKg");
	this.shape_2.setTransform(5.1375,102.0638,1.348,1.348,0,0,180);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#DEA27B").s().p("AgMAMQgKgKgBgRQATAWAKgCQAJgCgCgVQALAUAAAFQAAAIgPADIgGABQgIAAgHgHg");
	this.shape_3.setTransform(136.7074,97.1249,1.348,1.348,0,0,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DEA27B").s().p("AgNANQgLgLgCgHQgCgLAHgSQAPAeAMAMQAMAOAJgLQACAYgLAAQgKAAgVgWg");
	this.shape_4.setTransform(113.7202,88.2561,1.348,1.348,0,0,180);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#DEA27B").s().p("AAAAdQgYgGAAgPIALgmQADAlAIAJQAJALARgkQADAXgIAKQgFAHgIAAIgGgCg");
	this.shape_5.setTransform(82.6498,84.1373,1.348,1.348,0,0,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#DEA27B").s().p("AAXgZIgDAVQgKAXggAHQApgmAEgNg");
	this.shape_6.setTransform(167.7948,67.893,1.348,1.348,0,0,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#DEA27B").s().p("AgXARQgSgBAigQIAmgRIgRARQgSASgSAAIgBgBg");
	this.shape_7.setTransform(156.6351,86.8354,1.348,1.348,0,0,180);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DEA27B").s().p("AAMgJQASgCANADQgEALhSAIQAUgSAjgCg");
	this.shape_8.setTransform(130.8101,71.4946,1.348,1.348,0,0,180);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DEA27B").s().p("AgnAHQAsgJAigHQgQARggACg");
	this.shape_9.setTransform(140.5828,37.328,1.348,1.348,0,0,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#DEA27B").s().p("AgOAFIgegLQArAIAugIQgSANgXAAQgIAAgKgCg");
	this.shape_10.setTransform(94.7858,28.5071,1.348,1.348,0,0,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#DEA27B").s().p("AgogDIAkACQAlABAIgJQgEAJgMAGQgJAEgLAAQgTAAgagNg");
	this.shape_11.setTransform(96.6729,64.0447,1.348,1.348,0,0,180);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DEA27B").s().p("AAFAQQgPgIgIgQIAJgMQANAdAPANQgGgBgIgFg");
	this.shape_12.setTransform(40.1597,113.1171,1.348,1.348,0,0,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DEA27B").s().p("AAQAUQgfgCgbglIAfARQAjAPATABQgJAGgNAAIgFAAg");
	this.shape_13.setTransform(63.8164,66.1154,1.348,1.348,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DEA27B").s().p("AgqgQIAfAOQAkANASgCQgPAHgRABIgDAAQgiAAgQghg");
	this.shape_14.setTransform(55.1894,34.8046,1.348,1.348,0,0,180);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#DEA27B").s().p("AjUBRQBUgUBhggQCtg4BHg4Qg2AthKApQiNBRhzAAQgVAAgUgDg");
	this.shape_15.setTransform(111.0287,113.7636,1.348,1.348,0,0,180);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#DEA27B").s().p("AhTAUQBxhtCMggQhEAmhNAxQiYBigqA6QAdgwA5g2g");
	this.shape_16.setTransform(100.919,130.4047,1.348,1.348,0,0,180);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#DEA27B").s().p("AhLAHIgehCQA2AzAyAaQA/AjAtgOQgGAQgaAEIgMABQgzAAhXg1g");
	this.shape_17.setTransform(81.3,186.1724);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#F8B786").s().p("AlHP4IgMq9QgHg+g3jUQg0jKAAgTQAAgOgshKQg7higfg2Qh6jWAygbQAsgYBoCZIBSB+QAuBHAVAZQAUAWALgCQAIgCgBgVIAAgBQgCghgdhmQgmiAgRhDQhEj/A1gcQA0gcBHDaQATA8AmB+QAhBsAXAwQAPAeANANQAMAOAJgLQAQgTAFhrIAIjdQANkyBBgMQBCgNAKD0QADA9gBCNQAAB3AEApQADAmAIAIQAKALAQgkQAQgjAehgIA2ixQBIjfAogBQA+gCgLB6QgLB4hRD0QhSD3AWBqQALAyAigMQAmgOA6hUIAegqQAdgnAggdIAKgIQBQhBBRAKQAfAEAVAOQAUANACANQACAKgIAFQgIAFgVALQgVAMgOAJQhTA6hVCxQhECPhFBAQgoAlhUA6IgQAOQg/A7AQFFQAICjAUCWg");
	this.shape_18.setTransform(91.099,136.9687,1.348,1.348,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,182.1,274), null);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2D2D").s().p("AAYCFQgHgEgDgIIhDjkQgDgJAEgHQAEgIAIgDQAIgCAIAEQAIAEADAIIBEDlQACAIgEAIQgEAHgJADIgGABQgFAAgFgDg");
	this.shape.setTransform(37.8277,105.0399,1.348,1.348);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#373434").s().p("AgZArQgRgKgGgUQgGgSALgTQALgTAUgFIADgBQASgEASAKQARALAFATQAGAUgLASQgKASgUAGIgDABIgLABQgNAAgMgIg");
	this.shape_1.setTransform(42.2564,119.3117,1.348,1.348);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F2D2D").s().p("AgaAvQgTgLgGgWQgGgUALgUQALgTAVgGQAVgGAUALQATAMAGAVQAGAVgLASQgLAUgWAGQgIACgGAAQgNAAgNgHg");
	this.shape_2.setTransform(42.4782,119.9686,1.348,1.348);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#453F3F").s().p("AgoCxQgIgCgDgHQgMgigahwQgShKgJhSQgBgIAIgFQARgNAlgJQAegIAfABQAJABADAHQAeBAAYBIQAkBvAJAnQACAHgGAGQgGAGgIgBQgmgDgbAHQgfAIgcAZQgGAEgGAAIgDAAg");
	this.shape_3.setTransform(44.3574,123.3185,1.348,1.348);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F2D2D").s().p("AgNCOQgFgFgBgJIAAkAQABgHAFgGQAGgGAHAAQAIAAAGAGQAFAGABAHIAAEAQgBAJgFAFQgGAGgIAAQgHAAgGgGg");
	this.shape_4.setTransform(86.8261,92.4702,1.348,1.348);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#373434").s().p("AgpAtQgSgRgBgYQgCgYARgUQARgTAZgBIADAAQAYAAASAQQASARABAYQACAZgRASQgQATgaACIgEAAQgXAAgSgQg");
	this.shape_5.setTransform(86.7924,109.623,1.348,1.348);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F2D2D").s().p("AgqAxQgUgSgCgbQgCgaASgUQASgUAbgCQAagBAUASQAUARACAbQABAagRAUQgSAUgbACIgEAAQgYAAgSgQg");
	this.shape_6.setTransform(86.8543,110.4374,1.348,1.348);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#453F3F").s().p("ABXC2QgmgPgqgCQgugBgrAPQgFACgFgDQgFgDAAgGQgDhWAFhWQAFhSAJhFQACgNANgEQAmgLAkABQAfABAeAJQAPAEACAQQAIBHADBIQAEBVgDBiQgBAEgDACIgFABIgCAAg");
	this.shape_7.setTransform(86.2735,112.9423,1.348,1.348);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#AC9CCB").s().p("AjODKQgWAAgPgPQgPgQAAgVIAAkqQAAgWAPgPQAPgQAWAAIGdAAQAWAAAPAQQAPAPAAAWIAAEqQAAAVgPAQQgPAPgWAAg");
	this.shape_8.setTransform(75.6717,329.2059,1.348,1.348);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#453F3F").s().p("Ak7S/QAFgxAUguQAohdBhhKQBEg0B4g5QCVhHAwgZQBug5BOg6QBdhEBChTQBAhQAzhuQBgjNAijwQAkkEhGjVQgghjhDh4QgkhDgYgeQghgrg2gdQhPgtiKgzQh2gthwgWQjsgwjMAwQhlAYhXAtQhdAwhHBFQhbBZgeBaQgQA0gDBDQgBAqAFBOQAAAMgMAAQgNAAAAgMQgFhKABguQAEh/BAheQA4hTBYhDQBQg8BkgoQBeglBpgPQDUgfD2BCQBwAfB2AxQA6AZAzAZQA+AfAiAhQAhAgAiA6QAbAtAeA+QA7B1AbBtQA0DbgxEHQguD6hnDAQg4BphJBPQhGBLhkBCQhTA3hvA3IhpAyQhDAgglATQkBCEgTC7QgBAMgMAAQgNAAABgMg");
	this.shape_9.setTransform(146.0335,165.4011,1.348,1.348);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#453F3F").s().p("AlXQ+QgMgDAEgMQAKgfAPghQAuhlB4iEQCWikAkg2QAkg0AvhhQA2hwAZgpQAfgyA7hRQBDhdAYgkQBkiZAQiHQASiWg7igQg6iahvh0Qh4h+iUgqQhQgXhRAEQhXAGhGAlQg9AggvA6QgqA2gbBGQgEALgMgDQgMgDAEgMQAOglAQgdQAjhCA1gvQA4gyBEgXQBQgbBZAEQBWAFBQAgQCRA6BxCFQBrB9AyCdQA0CigbCcQgNBKgmBPQgfBBgzBJIheCEQg4BPggA4QgeA2g0BvQgmBNgxA/Qg6BNiJCRQh1CGgkB1QgDAJgIAAIgFgBg");
	this.shape_10.setTransform(153.7861,185.5586,1.348,1.348);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F8D4B1").s().p("AgjASQgCgGAjgRIAlgTQACAHgBADIgFAFIgdAOQgVALgOAJg");
	this.shape_11.setTransform(177.121,180.9301,1.348,1.348);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#DEA27B").s().p("AgkAQQgCgFAkgSQAdgPAKgDQABAJgIAGQgHAFgVAKQgUALgOAKg");
	this.shape_12.setTransform(176.9125,180.9638,1.348,1.348);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#DEA27B").s().p("AgMAMQgKgKgBgRQATAWAKgCQAJgCgCgVQALAUAAAFQAAAIgPADIgGABQgIAAgHgHg");
	this.shape_13.setTransform(45.3426,176.0249,1.348,1.348);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#DEA27B").s().p("AgNANQgLgLgCgHQgCgLAHgSQAPAeAMAMQAMAOAJgLQACAYgLAAQgKAAgVgWg");
	this.shape_14.setTransform(68.3298,167.1561,1.348,1.348);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#DEA27B").s().p("AAAAdQgYgGAAgPIALgmQADAlAIAJQAJALARgkQADAXgIAKQgFAHgIAAIgGgCg");
	this.shape_15.setTransform(99.4003,163.0373,1.348,1.348);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#DEA27B").s().p("AAXgZIgDAVQgKAXggAHQApgmAEgNg");
	this.shape_16.setTransform(14.2552,146.793,1.348,1.348);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#DEA27B").s().p("AgXARQgSgBAigQIAmgRIgRARQgSASgSAAIgBgBg");
	this.shape_17.setTransform(25.4149,165.7354,1.348,1.348);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DEA27B").s().p("AAMgJQASgCANADQgEALhSAIQAUgSAjgCg");
	this.shape_18.setTransform(51.2399,150.3946,1.348,1.348);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#DEA27B").s().p("AgnAHQAsgJAigHQgQARggACg");
	this.shape_19.setTransform(41.4672,116.228,1.348,1.348);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#DEA27B").s().p("AgOAFIgegLQArAIAugIQgSANgXAAQgIAAgKgCg");
	this.shape_20.setTransform(87.2642,107.4071,1.348,1.348);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#DEA27B").s().p("AgogDIAkACQAlABAIgJQgEAJgMAGQgJAEgLAAQgTAAgagNg");
	this.shape_21.setTransform(85.3771,142.9447,1.348,1.348);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#DEA27B").s().p("AAFAQQgPgIgIgQIAJgMQANAdAPANQgGgBgIgFg");
	this.shape_22.setTransform(141.8903,192.0171,1.348,1.348);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#DEA27B").s().p("AAQAUQgfgCgbglIAfARQAjAPATABQgJAGgNAAIgFAAg");
	this.shape_23.setTransform(118.2336,145.0154,1.348,1.348);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#DEA27B").s().p("AgqgQIAfAOQAkANASgCQgPAHgRABIgDAAQgiAAgQghg");
	this.shape_24.setTransform(126.8606,113.7046,1.348,1.348);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#DEA27B").s().p("AjUBRQBUgUBhggQCtg4BHg4Qg2AthKApQiNBRhzAAQgVAAgUgDg");
	this.shape_25.setTransform(71.0213,192.6636,1.348,1.348);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#DEA27B").s().p("AhTAUQBxhtCMggQhEAmhNAxQiYBigqA6QAdgwA5g2g");
	this.shape_26.setTransform(81.131,209.3047,1.348,1.348);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#DEA27B").s().p("AhMAKIgCg3QAoAlAlATQAvAaAhgKQgJAOgYAEQgJABgJAAQgqAAg+gkg");
	this.shape_27.setTransform(55.7556,264.573,1.348,1.348);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#DEA27B").s().p("AhGFkQgkodAthUQAthWBnAAIgQAPQg/A7AQFEQAICiAUCXg");
	this.shape_28.setTransform(102.7995,304.8752,1.348,1.348);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F8B786").s().p("AlHP4IgMq9QgHg+g3jUQg0jKAAgTQAAgOgshKQg7higfg2Qh6jWAygbQAsgYBoCZIBSB+QAuBHAVAZQAUAWALgCQAIgCgBgVIAAgBQgCghgdhmQgmiAgRhDQhEj/A1gcQA0gcBHDaQATA8AmB+QAhBsAXAwQAPAeANANQAMAOAJgLQAQgTAFhrIAIjdQANkyBBgMQBCgNAKD0QADA9gBCNQAAB3AEApQADAmAIAIQAKALAQgkQAQgjAehgIA2ixQBIjfAogBQA+gCgLB6QgLB4hRD0QhSD3AWBqQALAyAigMQAmgOA6hUIAegqQAdgnAggdIAKgIQBQhBBRAKQAfAEAVAOQAUANACANQACAKgIAFQgIAFgVALQgVAMgOAJQhTA6hVCxQhECPhFBAQgoAlhUA6IgQAOQg/A7AQFFQAICjAUCWg");
	this.shape_29.setTransform(90.951,215.8687,1.348,1.348);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,262.1,356.4), null);


// stage content:
(lib.data = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Symbol1();
	this.instance.setTransform(292.85,310.6,1,1,0,0,0,131.1,178.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:131,rotation:-0.5205,x:289.65,y:311.5},0).wait(1).to({rotation:-1.041,x:286.65,y:312.45},0).wait(1).to({rotation:-1.5615,x:283.55,y:313.45},0).wait(1).to({rotation:-2.0821,x:280.45,y:314.4},0).wait(1).to({rotation:-2.6026,x:277.45,y:315.3},0).wait(1).to({rotation:-3.1231,x:274.4,y:316.25},0).wait(1).to({rotation:-3.6436,x:271.35,y:317.25},0).wait(1).to({rotation:-4.1641,x:268.3,y:318.2},0).wait(1).to({rotation:-4.6846,x:265.2,y:319.1},0).wait(1).to({rotation:-5.2051,x:262.15,y:320},0).wait(1).to({rotation:-5.7256,x:259.15,y:321},0).wait(1).to({rotation:-4.6902,x:266.55,y:318.95},0).wait(1).to({rotation:-3.6548,x:274.05,y:316.9},0).wait(1).to({rotation:-2.6194,x:281.5,y:314.85},0).wait(1).to({rotation:-1.584,x:288.95,y:312.85},0).wait(1).to({rotation:-0.5485,x:296.45,y:310.8},0).wait(1).to({rotation:0.4869,x:303.95,y:308.75},0).wait(1).to({rotation:1.5223,x:311.35,y:306.75},0).wait(1).to({rotation:2.5577,x:318.85,y:304.65},0).wait(1).to({rotation:3.5931,x:326.35,y:302.6},0).wait(1).to({rotation:4.6286,x:333.75,y:300.55},0).wait(1).to({rotation:5.664,x:341.25,y:298.6},0).wait(1).to({rotation:6.6994,x:348.7,y:296.55},0).wait(1).to({rotation:6.3644,x:345.95,y:297.2},0).wait(1).to({rotation:6.0295,x:343.1,y:297.9},0).wait(1).to({rotation:5.6945,x:340.3,y:298.6},0).wait(1).to({rotation:5.3595,x:337.55,y:299.3},0).wait(1).to({rotation:5.0245,x:334.75,y:300},0).wait(1).to({rotation:4.6896,x:331.95,y:300.7},0).wait(1).to({rotation:4.3546,x:329.1,y:301.45},0).wait(1).to({rotation:4.0196,x:326.35,y:302.15},0).wait(1).to({rotation:3.6847,x:323.55,y:302.85},0).wait(1).to({rotation:3.3497,x:320.75,y:303.55},0).wait(1).to({rotation:3.0147,x:317.95,y:304.25},0).wait(1).to({rotation:2.6798,x:315.1,y:304.9},0).wait(1).to({rotation:2.3448,x:312.35,y:305.65},0).wait(1).to({rotation:2.0098,x:309.5,y:306.35},0).wait(1).to({rotation:1.6748,x:306.75,y:307.05},0).wait(1).to({rotation:1.3399,x:303.95,y:307.75},0).wait(1).to({rotation:1.0049,x:301.15,y:308.45},0).wait(1).to({rotation:0.6699,x:298.3,y:309.2},0).wait(1).to({rotation:0.335,x:295.5,y:309.85},0).wait(1).to({rotation:0,x:292.75,y:310.6},0).wait(1));

	// Layer_3
	this.instance_1 = new lib.Symbol2();
	this.instance_1.setTransform(582.3,351.85,1,1,0,0,0,91,137);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({rotation:0.4153,x:583.75,y:350.4},0).wait(1).to({rotation:0.8305,x:585.2,y:349},0).wait(1).to({rotation:1.2458,x:586.65,y:347.65},0).wait(1).to({rotation:1.6611,x:588.15,y:346.25},0).wait(1).to({rotation:2.0763,x:589.65,y:344.8},0).wait(1).to({rotation:2.4916,x:591.05,y:343.4},0).wait(1).to({rotation:2.9068,x:592.55,y:342},0).wait(1).to({rotation:3.3221,x:594,y:340.6},0).wait(1).to({rotation:3.7374,x:595.45,y:339.25},0).wait(1).to({rotation:4.1526,x:596.95,y:337.85},0).wait(1).to({rotation:4.5679,x:598.4,y:336.4},0).wait(1).to({rotation:4.9832,x:599.85,y:335.05},0).wait(1).to({rotation:5.3984,x:601.35,y:333.6},0).wait(1).to({rotation:5.8137,x:602.8,y:332.2},0).wait(1).to({rotation:6.229,x:604.25,y:330.8},0).wait(1).to({rotation:5.4101,x:601.9,y:332.55},0).wait(1).to({rotation:4.5912,x:599.5,y:334.25},0).wait(1).to({rotation:3.7723,x:597.1,y:335.95},0).wait(1).to({rotation:2.9535,x:594.7,y:337.65},0).wait(1).to({rotation:2.1346,x:592.3,y:339.35},0).wait(1).to({rotation:1.3157,x:589.9,y:341.05},0).wait(1).to({rotation:0.4968,x:587.45,y:342.8},0).wait(1).to({rotation:-0.322,x:585.05,y:344.5},0).wait(1).to({rotation:-1.1409,x:582.7,y:346.2},0).wait(1).to({rotation:-1.9598,x:580.3,y:347.9},0).wait(1).to({rotation:-2.7786,x:577.9,y:349.65},0).wait(1).to({rotation:-3.5975,x:575.45,y:351.35},0).wait(1).to({rotation:-4.4164,x:573.1,y:353.05},0).wait(1).to({rotation:-5.2353,x:570.65,y:354.75},0).wait(1).to({rotation:-6.0541,x:568.3,y:356.45},0).wait(1).to({rotation:-6.873,x:565.9,y:358.15},0).wait(1).to({rotation:-7.6919,x:563.5,y:359.85},0).wait(1).to({rotation:-8.5108,x:561.1,y:361.6},0).wait(1).to({rotation:-7.6597,x:563.2,y:360.6},0).wait(1).to({rotation:-6.8086,x:565.35,y:359.65},0).wait(1).to({rotation:-5.9575,x:567.4,y:358.65},0).wait(1).to({rotation:-5.1065,x:569.6,y:357.65},0).wait(1).to({rotation:-4.2554,x:571.65,y:356.7},0).wait(1).to({rotation:-3.4043,x:573.85,y:355.7},0).wait(1).to({rotation:-2.5532,x:575.9,y:354.75},0).wait(1).to({rotation:-1.7022,x:578,y:353.8},0).wait(1).to({rotation:-0.8511,x:580.2,y:352.8},0).wait(1).to({rotation:0,x:582.3,y:351.85},0).wait(1));

	// Layer_11
	this.instance_2 = new lib.Symbol9();
	this.instance_2.setTransform(245.45,397.6,1,1,0,0,0,5.2,5.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).wait(1).to({rotation:-53.3333,x:156.9,y:438.85},0).wait(1).to({rotation:-106.6667,x:62.75,y:452.6},0).wait(1).to({rotation:-160,x:88.2,y:364},0).wait(1).to({rotation:-213.3333,x:108.4,y:344.3},0).wait(1).to({rotation:-266.6667,x:137.3,y:341.1},0).wait(1).to({rotation:-320,x:166.9,y:343.75},0).wait(1).to({rotation:-373.3333,x:196.25,y:348.1},0).wait(1).to({rotation:-426.6667,x:175,y:334.6},0).wait(1).to({rotation:-480,x:149.4,y:319.45},0).wait(1).to({rotation:-533.3333,x:123.2,y:309.35},0).wait(1).to({rotation:-586.6667,x:100.35,y:293.3},0).wait(1).to({rotation:-640,x:85.05,y:270.05},0).wait(1).to({rotation:-693.3333,x:80.25,y:242.6},0).wait(1).to({rotation:-746.6667,x:83.9,y:214.75},0).wait(1).to({rotation:-800,x:92.5,y:188.05},0).wait(1).to({rotation:-853.3333,x:104.25,y:162.45},0).wait(1).to({rotation:-906.6667,x:117.95,y:138.05},0).wait(1).to({rotation:-960,x:133.1,y:114.5},0).wait(1).to({rotation:-1013.3333,x:149.35,y:91.55},0).wait(1).to({rotation:-1066.6667,x:145.15,y:61.4},0).wait(1).to({rotation:-1120,x:136.7,y:32.1},0).wait(1).to({rotation:-1173.3333,x:122.05,y:5.35},0).wait(1).to({rotation:-1226.6667,x:99.7,y:-15.25},0).wait(1).to({rotation:-1280,x:71.35,y:-26.35},0).wait(1).to({rotation:-1333.3333,x:41,y:-28.4},0).wait(1).to({rotation:-1386.6667,x:10.85,y:-24.4},0).wait(1).to({rotation:-1440,x:-18.5,y:-16.4},0).wait(1));

	// Layer_5_copy_copy
	this.instance_3 = new lib.Symbol3();
	this.instance_3.setTransform(167.1,417.2,1,1,0,0,0,9.1,9.1);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(5).to({_off:false},0).wait(1).to({rotation:37.8947,x:184.65,y:437.95,alpha:0.2},0).wait(1).to({rotation:75.7895,x:198.5,y:461.2,alpha:0.4},0).wait(1).to({rotation:113.6842,x:190.8,y:483.8,alpha:0.6},0).wait(1).to({rotation:151.5789,x:163.95,y:486.1,alpha:0.8},0).wait(1).to({rotation:189.4737,x:137,y:482.2,alpha:1},0).wait(1).to({rotation:227.3684,x:119.75,y:472.05},0).wait(1).to({rotation:265.2632,x:103,y:460.95},0).wait(1).to({rotation:303.1579,x:86.65,y:449.3},0).wait(1).to({rotation:341.0526,x:70.6,y:437.2},0).wait(1).to({rotation:378.9474,x:54.8,y:424.65},0).wait(1).to({rotation:416.8421,x:39.45,y:411.7},0).wait(1).to({rotation:454.7368,x:24.45,y:398.2},0).wait(1).to({rotation:492.6316,x:10,y:384.15},0).wait(1).to({rotation:530.5263,x:-3.75,y:369.3},0).wait(1).to({rotation:568.4211,x:-16.3,y:353.7},0).wait(1).to({rotation:606.3158,x:-27.35,y:336.9},0).wait(1).to({rotation:644.2105,x:-35.4,y:318.6},0).wait(1).to({rotation:682.1053,x:-26.7,y:306.3},0).wait(1).to({rotation:720,x:-7.35,y:301},0).wait(1).to({rotation:757.8947,x:12.1,y:296.35},0).wait(1).to({rotation:795.7895,x:31.75,y:292.25},0).wait(1).to({rotation:833.6842,x:50.85,y:286.15},0).wait(1).to({rotation:871.5789,x:67.4,y:274.85},0).wait(1).to({rotation:909.4737,x:78.1,y:257.95},0).wait(1).to({rotation:947.3684,x:88.8,y:240.9},0).wait(1).to({rotation:985.2632,x:89.35,y:228.5},0).wait(1).to({rotation:1023.1579,x:74.65,y:242.2},0).wait(1).to({rotation:1061.0526,x:58.85,y:254.7},0).wait(1).to({rotation:1098.9474,x:40.9,y:250.9},0).wait(1).to({rotation:1136.8421,x:23.7,y:240.45},0).wait(1).to({rotation:1174.7368,x:6.8,y:229.45},0).wait(1).to({rotation:1212.6316,x:-9.55,y:217.65},0).wait(1).to({rotation:1250.5263,x:-22.35,y:202.15},0).wait(1).to({rotation:1288.4211,x:-31.3,y:184.2},0).wait(1).to({rotation:1326.3158,x:-37.85,y:165.2},0).wait(1).to({rotation:1364.2105,x:-42.55,y:145.7},0).wait(1).to({rotation:1402.1053,x:-45.6,y:125.85},0).wait(1).to({rotation:1440,x:-46.45,y:105.8},0).wait(1));

	// Layer_5_copy
	this.instance_4 = new lib.Symbol3();
	this.instance_4.setTransform(143,371.55,1,1,0,0,0,9.1,9.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(13).to({_off:false},0).wait(1).to({rotation:48,x:147.85,y:358.25,alpha:0.25},0).wait(1).to({rotation:96,x:151.4,y:344.55,alpha:0.5},0).wait(1).to({rotation:144,x:153.4,y:330.45,alpha:0.75},0).wait(1).to({rotation:192,x:153.45,y:316.2,alpha:1},0).wait(1).to({rotation:240,x:147.15,y:305.7},0).wait(1).to({rotation:288,x:140.4,y:295.5},0).wait(1).to({rotation:336,x:133.25,y:285.55},0).wait(1).to({rotation:384,x:125.65,y:275.95},0).wait(1).to({rotation:432,x:117.6,y:266.65},0).wait(1).to({rotation:480,x:109.05,y:257.75},0).wait(1).to({rotation:528,x:100.05,y:249.35},0).wait(1).to({rotation:576,x:90.6,y:241.55},0).wait(1).to({rotation:624,x:80.6,y:234.55},0).wait(1).to({rotation:672,x:70.05,y:228.35},0).wait(1).to({rotation:720,x:59,y:223.05},0).wait(1).to({rotation:768,x:45.95,y:215.5},0).wait(1).to({rotation:816,x:30.7,y:211.8},0).wait(1).to({rotation:864,x:16.9,y:206.7},0).wait(1).to({rotation:912,x:3.5,y:199.5},0).wait(1).to({rotation:960,x:-9.2,y:191.4},0).wait(1).to({rotation:1008,x:-21.45,y:182.45},0).wait(1).to({rotation:1056,x:-33,y:172.65},0).wait(1).to({rotation:1104,x:-43.15,y:161.4},0).wait(1).to({rotation:1152,x:-51,y:148.35},0).wait(1).to({rotation:1200,x:-57.15,y:134.45},0).wait(1).to({rotation:1248,x:-61.95,y:119.95},0).wait(1).to({rotation:1296,x:-65.65,y:105.2},0).wait(1).to({rotation:1344,x:-68.4,y:90.3},0).wait(1).to({rotation:1392,x:-70.2,y:75.25},0).wait(1).to({rotation:1440,x:-70.55,y:60.15},0).wait(1));

	// Layer_9
	this.instance_5 = new lib.Symbol7();
	this.instance_5.setTransform(187.7,413.85,1,1,0,0,0,5.5,5.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(3).to({_off:false},0).wait(1).to({rotation:27,x:188.45,y:460.2},0).wait(1).to({rotation:54,x:175.35,y:487.3},0).wait(1).to({rotation:81,x:148.45,y:495.2},0).wait(1).to({rotation:108,x:107.65,y:483.85},0).wait(1).to({rotation:135,x:114.25,y:459.65},0).wait(1).to({rotation:162,x:119.85,y:436.4},0).wait(1).to({rotation:189,x:124.3,y:414.15},0).wait(1).to({rotation:216,x:127.75,y:392.9},0).wait(1).to({rotation:243,x:130.1,y:372.6},0).wait(1).to({rotation:270,x:131.4,y:353.25},0).wait(1).to({rotation:297,x:131.6,y:334.9},0).wait(1).to({rotation:324,x:130.8,y:317.45},0).wait(1).to({rotation:351,x:128.85,y:301.05},0).wait(1).to({rotation:378,x:125.9,y:285.6},0).wait(1).to({rotation:405,x:121.85,y:271.1},0).wait(1).to({rotation:432,x:116.75,y:257.55},0).wait(1).to({rotation:459,x:110.6,y:244.95},0).wait(1).to({rotation:486,x:103.35,y:233.3},0).wait(1).to({rotation:513,x:95.05,y:222.65},0).wait(1).to({rotation:540,x:85.7,y:212.95},0).wait(1).to({rotation:567,x:75.25,y:204.25},0).wait(1).to({rotation:594,x:63.75,y:196.45},0).wait(1).to({rotation:621,x:51.2,y:189.65},0).wait(1).to({rotation:648,x:37.55,y:183.8},0).wait(1).to({rotation:675,x:17.85,y:165.9},0).wait(1).to({rotation:702,x:-0.05,y:150.5},0).wait(1).to({rotation:729,x:-16.3,y:137.5},0).wait(1).to({rotation:756,x:-30.9,y:127.05},0).wait(1).to({rotation:783,x:-43.7,y:119},0).wait(1).to({rotation:810,x:-54.85,y:113.45},0).wait(1).to({rotation:837,x:-64.25,y:110.4},0).wait(1).to({rotation:864,x:-72,y:109.8},0).wait(1).to({rotation:891,x:-78,y:111.6},0).wait(1).to({rotation:918,x:-82.3,y:115.95},0).wait(1).to({rotation:945,x:-84.9,y:122.75},0).wait(1).to({rotation:972,x:-85.75,y:132},0).wait(1).to({rotation:999,x:-84.95,y:143.7},0).wait(1).to({rotation:1026,x:-82.45,y:158},0).wait(1).to({rotation:1053,x:-78.2,y:174.65},0).wait(1).to({rotation:1080,x:-72.3,y:193.85},0).wait(1));

	// Layer_8
	this.instance_6 = new lib.Symbol5();
	this.instance_6.setTransform(186.4,423.35,1,1,0,0,0,5.5,5.5);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(4).to({_off:false},0).wait(1).to({regX:5.6,regY:5.6,x:167.15,y:424.15},0).wait(1).to({x:148.1,y:420.8},0).wait(1).to({x:132.85,y:409.4},0).wait(1).to({x:127.8,y:391},0).wait(1).to({x:130.4,y:371.85},0).wait(1).to({x:136.5,y:353.45},0).wait(1).to({x:144.45,y:333.5},0).wait(1).to({x:151.4,y:313.2},0).wait(1).to({x:157.8,y:292.7},0).wait(1).to({x:163.7,y:272.05},0).wait(1).to({x:169.05,y:251.25},0).wait(1).to({x:173.9,y:230.3},0).wait(1).to({x:178,y:209.25},0).wait(1).to({x:181.25,y:188.05},0).wait(1).to({x:181.85,y:166.65},0).wait(1).to({x:176.25,y:146},0).wait(1).to({x:164.45,y:128.15},0).wait(1).to({x:148.25,y:114.15},0).wait(1).to({x:129.35,y:104},0).wait(1).to({x:109,y:97.25},0).wait(1).to({x:87.8,y:93.65},0).wait(1).to({x:66.4,y:93.35},0).wait(1).to({x:57.4,y:97.75},0).wait(1).to({x:48.1,y:101.45},0).wait(1).to({x:38.6,y:104.6},0).wait(1).to({x:28.95,y:107.25},0).wait(1).to({x:19.15,y:109.45},0).wait(1).to({x:9.25,y:111},0).wait(1).to({x:-0.65,y:111.85},0).wait(1).to({x:-10.7,y:111.75},0).wait(1).to({x:-20.55,y:110.2},0).wait(1).to({x:-29.85,y:106.5},0).wait(1).to({x:-38.05,y:100.75},0).wait(1).to({x:-45.7,y:94.3},0).wait(1).to({x:-52.75,y:87.2},0).wait(1).to({x:-59.25,y:79.55},0).wait(1).to({x:-65.05,y:71.4},0).wait(1).to({x:-70,y:62.7},0).wait(1).to({x:-73.55,y:53.35},0).wait(1));

	// Layer_7
	this.instance_7 = new lib.Symbol6();
	this.instance_7.setTransform(176.45,379.85,1,1,0,0,0,3.9,3.9);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(8).to({_off:false},0).wait(1).to({x:202.7,y:363.3},0).wait(1).to({x:222.65,y:348.45},0).wait(1).to({x:236.35,y:335.25},0).wait(1).to({x:243.75,y:323.75},0).wait(1).to({x:244.9,y:313.95},0).wait(1).to({x:239.75,y:305.8},0).wait(1).to({x:228.35,y:299.3},0).wait(1).to({x:210.7,y:294.45},0).wait(1).to({x:186.7,y:291.3},0).wait(1).to({x:156.45,y:289.85},0).wait(1).to({x:138.5,y:308.65},0).wait(1).to({x:122.15,y:325},0).wait(1).to({x:107.3,y:338.8},0).wait(1).to({x:94.1,y:350.1},0).wait(1).to({x:82.4,y:358.9},0).wait(1).to({x:72.25,y:365.15},0).wait(1).to({x:63.65,y:368.95},0).wait(1).to({x:56.65,y:370.2},0).wait(1).to({x:51.2,y:368.95},0).wait(1).to({x:47.25,y:365.15},0).wait(1).to({x:44.9,y:358.9},0).wait(1).to({x:44.1,y:350.1},0).wait(1).to({x:44.85,y:338.8},0).wait(1).to({x:47.15,y:325},0).wait(1).to({x:51,y:308.7},0).wait(1).to({x:56.45,y:289.85},0).wait(1).to({x:69.45,y:265.5},0).wait(1).to({x:77.25,y:242.8},0).wait(1).to({x:79.9,y:221.75},0).wait(1).to({x:77.3,y:202.35},0).wait(1).to({x:69.55,y:184.55},0).wait(1).to({x:56.6,y:168.4},0).wait(1).to({x:38.45,y:153.9},0).wait(1).to({x:15.05,y:141.05},0).wait(1).to({x:-13.5,y:129.85},0).wait(1));

	// Layer_6
	this.instance_8 = new lib.Symbol4();
	this.instance_8.setTransform(226.95,358.5,1,1,0,0,0,8.2,8.2);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({_off:false},0).wait(1).to({rotation:-26.3415,x:218.55,y:349.9,alpha:0.125},0).wait(1).to({rotation:-52.6829,x:207.1,y:347.55,alpha:0.25},0).wait(1).to({rotation:-79.0244,x:197.7,y:354.75,alpha:0.375},0).wait(1).to({rotation:-105.3659,x:191.35,y:365.05,alpha:0.5},0).wait(1).to({rotation:-131.7073,x:186.45,y:376.1,alpha:0.625},0).wait(1).to({rotation:-158.0488,x:182.5,y:387.45,alpha:0.75},0).wait(1).to({rotation:-184.3902,x:179,y:398.95,alpha:0.875},0).wait(1).to({rotation:-210.7317,x:176,y:410.6,alpha:1},0).wait(1).to({rotation:-237.0732,x:165.45,y:422.75},0).wait(1).to({rotation:-263.4146,x:153.7,y:433.65},0).wait(1).to({rotation:-289.7561,x:140.3,y:442.55},0).wait(1).to({rotation:-316.0976,x:125.2,y:448.05},0).wait(1).to({rotation:-342.439,x:109.2,y:448.25},0).wait(1).to({rotation:-368.7805,x:94,y:443.05},0).wait(1).to({rotation:-395.122,x:80.75,y:433.95},0).wait(1).to({rotation:-421.4634,x:69.4,y:422.6},0).wait(1).to({rotation:-447.8049,x:59.5,y:410},0).wait(1).to({rotation:-474.1463,x:50.7,y:396.55},0).wait(1).to({rotation:-500.4878,x:42.7,y:382.6},0).wait(1).to({rotation:-526.8293,x:32.9,y:375.1},0).wait(1).to({rotation:-553.1707,x:24.85,y:366},0).wait(1).to({rotation:-579.5122,x:18.55,y:354.95},0).wait(1).to({rotation:-605.8537,x:12.7,y:344.05},0).wait(1).to({rotation:-632.1951,x:7.1,y:332.9},0).wait(1).to({rotation:-658.5366,x:1.7,y:321.65},0).wait(1).to({rotation:-684.878,x:-3.45,y:310.4},0).wait(1).to({rotation:-711.2195,x:-8.55,y:299.1},0).wait(1).to({rotation:-737.561,x:-15.85,y:289.1},0).wait(1).to({rotation:-763.9024,x:-25.65,y:281.6},0).wait(1).to({rotation:-790.2439,x:-36.95,y:276.45},0).wait(1).to({rotation:-816.5854,x:-48.85,y:273.05},0).wait(1).to({rotation:-842.9268,x:-61.05,y:271.1},0).wait(1).to({rotation:-869.2683,x:-73.4,y:270.25},0).wait(1).to({rotation:-895.6098,x:-85.8,y:270.45},0).wait(1).to({rotation:-921.9512,x:-98.1,y:271.75},0).wait(1).to({rotation:-948.2927,x:-110.2,y:274.4},0).wait(1).to({rotation:-974.6341},0).wait(1).to({rotation:-1000.9756,x:-110.25,y:274.35},0).wait(1).to({rotation:-1027.3171,y:274.3},0).wait(1).to({rotation:-1053.6585,x:-110.3,y:274.35},0).wait(1).to({rotation:-1080,x:-110.35,y:274.4},0).wait(1));

	// Layer_10_copy
	this.instance_9 = new lib.Symbol8();
	this.instance_9.setTransform(229.3,464.7,1,1,0,0,0,4.8,4.8);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(16).to({_off:false},0).wait(1).to({x:251.5,y:441.55},0).wait(1).to({x:265.25,y:421},0).wait(1).to({x:270.45,y:403.15},0).wait(1).to({x:267,y:387.95},0).wait(1).to({x:254.8,y:375.5},0).wait(1).to({x:234,y:365.85},0).wait(1).to({x:204.65,y:359},0).wait(1).to({x:167,y:354.85},0).wait(1).to({x:133.15,y:366.05},0).wait(1).to({x:99.35,y:375.2},0).wait(1).to({x:68.5,y:379.95},0).wait(1).to({x:46.8,y:376.75},0).wait(1).to({x:40.1,y:364.2},0).wait(1).to({x:46.35,y:345.8},0).wait(1).to({x:59.9,y:325.35},0).wait(1).to({x:76.95,y:304.85},0).wait(1).to({x:97.8,y:276.9},0).wait(1).to({x:108.35,y:255.2},0).wait(1).to({x:112.8,y:236.6},0).wait(1).to({x:112.7,y:219.85},0).wait(1).to({x:108.7,y:204.3},0).wait(1).to({x:100.95,y:189.6},0).wait(1).to({x:89.3,y:175.3},0).wait(1).to({x:73.15,y:161.25},0).wait(1).to({x:51.4,y:146.95},0).wait(1).to({x:21.55,y:131.95},0).wait(1).to({x:-23,y:114.85},0).wait(1));

	// Layer_10
	this.instance_10 = new lib.Symbol8();
	this.instance_10.setTransform(233.55,399.15,1,1,0,0,0,4.8,4.8);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(13).to({_off:false},0).wait(1).to({x:253.8,y:378.3},0).wait(1).to({x:267.3,y:359.6},0).wait(1).to({x:273.95,y:343.1},0).wait(1).to({x:273.85,y:328.75},0).wait(1).to({x:266.9,y:316.55},0).wait(1).to({x:253.2,y:306.5},0).wait(1).to({x:232.7,y:298.6},0).wait(1).to({x:205.35,y:292.85},0).wait(1).to({x:171.25,y:289.3},0).wait(1).to({x:154.25,y:293.45},0).wait(1).to({x:136.55,y:296.45},0).wait(1).to({x:118.65,y:297.3},0).wait(1).to({x:102.05,y:294.65},0).wait(1).to({x:89.3,y:287.55},0).wait(1).to({x:81.85,y:276.9},0).wait(1).to({x:79,y:264.5},0).wait(1).to({x:79.15,y:251.75},0).wait(1).to({x:81.2,y:239.3},0).wait(1).to({x:100.65,y:213.6},0).wait(1).to({x:111.2,y:193.25},0).wait(1).to({x:116.35,y:175.7},0).wait(1).to({x:117.45,y:159.85},0).wait(1).to({x:115.1,y:145.2},0).wait(1).to({x:109.55,y:131.3},0).wait(1).to({x:100.8,y:118},0).wait(1).to({x:88.55,y:104.95},0).wait(1).to({x:72.3,y:91.95},0).wait(1).to({x:51,y:78.8},0).wait(1).to({x:22.45,y:64.9},0).wait(1).to({x:-18.75,y:49.3},0).wait(1));

	// Layer_5
	this.instance_11 = new lib.Symbol3();
	this.instance_11.setTransform(181.45,461.7,1,1,0,0,0,9.1,9.1);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(4).to({_off:false},0).wait(1).to({rotation:41.1429,x:185.4,y:451.1,alpha:0.2},0).wait(1).to({rotation:82.2857,x:188.6,y:440.2,alpha:0.4},0).wait(1).to({rotation:123.4286,x:190.85,y:429.1,alpha:0.6},0).wait(1).to({rotation:164.5714,x:192.1,y:417.75,alpha:0.8},0).wait(1).to({rotation:205.7143,x:191.95,y:406.4,alpha:1},0).wait(1).to({rotation:246.8571,x:190.2,y:394.8},0).wait(1).to({rotation:288,x:186.9,y:383.6},0).wait(1).to({rotation:329.1429,x:181.85,y:373.05},0).wait(1).to({rotation:370.2857,x:175.4,y:363.25},0).wait(1).to({rotation:411.4286,x:167.7,y:354.4},0).wait(1).to({rotation:452.5714,x:159.05,y:346.4},0).wait(1).to({rotation:493.7143,x:149.7,y:339.2},0).wait(1).to({rotation:534.8571,x:139.95,y:332.75},0).wait(1).to({rotation:576,x:129.7,y:327},0).wait(1).to({rotation:617.1429,x:119.2,y:321.9},0).wait(1).to({rotation:658.2857,x:108.4,y:317.3},0).wait(1).to({rotation:699.4286,x:97.4,y:313.15},0).wait(1).to({rotation:740.5714,x:86.75,y:306.55},0).wait(1).to({rotation:781.7143,x:74.65,y:302.85},0).wait(1).to({rotation:822.8571,x:62.35,y:299.95},0).wait(1).to({rotation:864,x:50.8,y:294.6},0).wait(1).to({rotation:905.1429,x:39.75,y:288.4},0).wait(1).to({rotation:946.2857,x:29.15,y:281.5},0).wait(1).to({rotation:987.4286,x:18.95,y:274.15},0).wait(1).to({rotation:1028.5714,x:9.2,y:266.15},0).wait(1).to({rotation:1069.7143,x:0.05,y:257.45},0).wait(1).to({rotation:1110.8571,x:-7.5,y:247.3},0).wait(1).to({rotation:1152,x:-13.7,y:236.25},0).wait(1).to({rotation:1193.1429,x:-18.7,y:224.55},0).wait(1).to({rotation:1234.2857,x:-22.75,y:212.55},0).wait(1).to({rotation:1275.4286,x:-26.05,y:200.35},0).wait(1).to({rotation:1316.5714,x:-28.65,y:187.9},0).wait(1).to({rotation:1357.7143,x:-30.7,y:175.45},0).wait(1).to({rotation:1398.8571,x:-31.9,y:162.85},0).wait(1).to({rotation:1440,x:-32.1,y:150.3},0).wait(5));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(278.1,215.2,426,291.5);
// library properties:
lib.properties = {
	id: '6579C001F29F594C90FBF5C785F9AE3D',
	width: 800,
	height: 500,
	fps: 30,
	color: "#FFFFFF",
	opacity: 0.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6579C001F29F594C90FBF5C785F9AE3D'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;